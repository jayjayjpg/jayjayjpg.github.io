function drawOnCanvas(circle){
  // drawing code here
  // circle(position x, position y);

}