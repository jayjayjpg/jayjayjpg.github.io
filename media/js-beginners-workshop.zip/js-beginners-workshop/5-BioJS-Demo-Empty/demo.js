var featureViewer = require("biojs-vis-proteinfeaturesviewer");
var sequenceViewer = require("sequence-viewer");

var features = document.getElementById("features");

var fvInstance = new featureViewer({
    el: features,
    uniprotacc: "P04637"
});


fvInstance.getDispatcher().on("ready", function () {
    var svInstance = new sequenceViewer(fvInstance.sequence);
    svInstance.render('#sequence', {charsPerLine: 100});
});

